/*
 * mode_entry.h
 *
 *  Created on: Feb 26, 2016
 *      Author: B48683
 */

#ifndef MODE_ENTRY_H_
#define MODE_ENTRY_H_

void PLL_160MHz (void);
void system160mhz (void);
void enter_STOP_mode (void);

#endif /* MODE_ENTRY_H_ */
