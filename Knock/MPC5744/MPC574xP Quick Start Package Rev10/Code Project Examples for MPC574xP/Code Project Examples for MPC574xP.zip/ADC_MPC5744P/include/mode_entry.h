/*
 * mode_entry.h
 *
 *  Created on: Feb 26, 2016
 *      Author: B48683
 */

#ifndef MODE_ENTRY_H_
#define MODE_ENTRY_H_

void PLL_160MHz();

void system160mhz();

void enter_STOP_mode();

#endif /* MODE_ENTRY_H_ */
