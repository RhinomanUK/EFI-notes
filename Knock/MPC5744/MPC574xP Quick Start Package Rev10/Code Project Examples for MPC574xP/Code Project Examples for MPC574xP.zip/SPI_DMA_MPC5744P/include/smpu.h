/*
 * smpu.h
 *
 */

#ifndef SMPU_H_
#define SMPU_H_

#include "project.h"

void smpu_config(void);

#endif /* SMPU_H_ */
