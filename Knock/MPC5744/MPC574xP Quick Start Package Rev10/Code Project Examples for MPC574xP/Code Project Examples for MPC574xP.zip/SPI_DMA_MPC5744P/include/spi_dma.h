/*
 * spi_dma.h
 *
 *  Created on: Mar 28, 2016
 *      Author: B48683
 */

#ifndef SPI_DMA_H_
#define SPI_DMA_H_

#include "project.h"

void init_dspi_2 (void);
void init_dspi_1 (void);
void init_dspi_ports(void);

#endif /* SPI_DMA_H_ */
